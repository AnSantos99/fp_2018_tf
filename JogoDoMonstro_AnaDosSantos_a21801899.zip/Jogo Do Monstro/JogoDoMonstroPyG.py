# **********************O Jogo do Monstro com classes**********************#
#  ------------ Ana Dos Santos ----------- N°Aluno: A21801899 -----------  #
# made in: PyCharm & IDLE PYTHON(3.7.1) 64-BIT
# Obti ajuda de videos no youtube como também de colegas da turma usando assim algumas ideas e soluções desses onde tinha
# mais dificuldades em resolver problemas sozinha.
# -------------------------------------------------------------------------#
import pygame, time
pygame.init()

#WindowSize
winSize = pygame.display.set_mode((500, 500))
pygame.display.set_caption("Jogo do Monstro")

#IMAGENS SPRITES
andarUp = [pygame.image.load("tile001.png"), pygame.image.load("tile002.png"), pygame.image.load("tile003.png"),
pygame.image.load("tile004.png"), pygame.image.load("tile005.png"), pygame.image.load("tile006.png"),
pygame.image.load("tile007.png"), pygame.image.load("tile008.png")]

andarleft = [pygame.image.load("tile010.png"), pygame.image.load("tile011.png"), pygame.image.load("tile012.png"),
pygame.image.load("tile013.png"), pygame.image.load("tile014.png"), pygame.image.load("tile015.png"),
pygame.image.load("tile016.png"), pygame.image.load("tile017.png"), pygame.image.load("tile018.png")]

andarDown = [pygame.image.load("tile020.png"), pygame.image.load("tile021.png"), pygame.image.load("tile022.png"),
pygame.image.load("tile023.png"), pygame.image.load("tile024.png"), pygame.image.load("tile025.png"),
pygame.image.load("tile026.png"), pygame.image.load("tile027.png"), pygame.image.load("tile028.png")]

andarRight = [pygame.image.load("tile030.png"), pygame.image.load("tile031.png"), pygame.image.load("tile032.png"),
pygame.image.load("tile033.png"), pygame.image.load("tile034.png"), pygame.image.load("tile035.png"),
pygame.image.load("tile036.png"), pygame.image.load("tile037.png"), pygame.image.load("tile038.png")]


items = [pygame.image.load('gold.png'), pygame.image.load('saida.png'), pygame.image.load('poco.png')]

#fundo e sprite inicial da personagem
background = pygame.image.load("mapa.jpg")
character = pygame.image.load('tile020.png')

#TIME AND MUSIC
clock = pygame.time.Clock()
music = pygame.mixer_music.load("mii_music.mp3")
pygame.mixer.music.play(-1)

#GLOBAL VARIABLES
armas = 4
tesouro = 0


class jogador(object):
    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.velocidade = 10
        self.left = False
        self.right = False
        self.up = False
        self.down = False
        self.parada = True
        self.contaCaminho = 0
        self.hitbox = (self.x + 10, self.y + 10, 20, 20)


    def desenha(self, winSize):
        if self.contaCaminho + 1 >= 27:
            self.contaCaminho = 0

        if not(self.parada):
            if self.left:
                winSize.blit(andarleft[self.contaCaminho//3], (self.x, self.y))
                self.contaCaminho += 1
            elif self.right:
                winSize.blit(andarRight[self.contaCaminho//3], (self.x, self.y))
                self.contaCaminho += 1
            elif self.down:
                winSize.blit(andarDown[self.contaCaminho//3], (self.x, self.y))
                self.contaCaminho += 1
            elif self.up:
                winSize.blit(andarUp[self.contaCaminho//3], (self.x, self.y))
                self.contaCaminho += 1
        else:
            if self.right:
                winSize.blit(andarRight[0], (self.x, self.y))
            elif self.left:
                winSize.blit(andarleft[0], (self.x, self.y))
            elif self.down:
                winSize.blit(andarDown[0], (self.x, self.y))
            elif self.up:
                winSize.blit(andarUp[0], (self.x, self.y))
            elif self.parada:
                winSize.blit(andarDown[0], (self.x, self.y))
        self.hitbox = (self.x + 10, self.y + 10, 20, 20)

    # se o jogador cai no poco ou colide com o monstro
    def atinge(self):
        self.x = 20
        self.y = 410
        self.contaCaminho = 0
        pygame.draw.rect(winSize, (0, 0, 0), (00, 460, 500, 100))
        text = font.render('* morreste! tenta de novo.', 1, (255, 255, 255))
        winSize.blit(text, (10, 465))
        pygame.display.update()
        i = 0
        while i < 100:
            pygame.time.delay(10)
            i += 1
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    i = 301
                    pygame.quit()


# definir lancamento da flecha
class projetil(object):
    def __init__(self, x, y, radius, cor, apontando):
        self.x = x
        self.y = y
        self.radius = radius
        self.cor = cor
        self.apontando = apontando
        self.velocidade = 8 * apontando
    #desenha flecha no mapa
    def desenha (self,winSize):
        if armas > 0:
            pygame.draw.circle(winSize, self.cor, (self.x,self.y), self.radius)


# definir stats do monstro
class monstro(object):
    direita = pygame.image.load("monstro_direita.png")
    esquerda = pygame.image.load("monstro_esquerda.png")

    def __init__(self, x, y, width, height, end):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.end = end
        self.caminho = [x, end]
        self.contaCaminho = 0
        self.velocidade = 10
        self.hitbox = (self.x + 10, self.y + 10, 20, 20)
        self.visivel = True

    #desenha monstro no mapa
    def desenha(self,winSize):
        self.move()
        if self.visivel:
            if self.contaCaminho + 1 >= 33:
                self.contaCaminho = 0

            if self.velocidade > 0:
                winSize.blit(self.direita[self.contaCaminho // 3], (self.x, self.y))
                self.contaCaminho += 1
            else:
                winSize.blit(self.esquerda[self.contaCaminho // 3], (self.x, self.y))
                self.contaCaminho += 1
            self.hitbox = (self.x + 10, self.y + 10, 20, 20)
    # movimento do monstro
    def move(self):
        if self.velocidade > 0:
            if self.x + self.velocidade < self.caminho[1]:
                self.x += self.velocidade
            else:
                self.velocidade = self.velocidade * -1
                self.contaCaminho
        else:
            if self.x - self.velocidade > self.caminho[0]:
                self.x += self.velocidade
            else:
                self.velocidade = self.velocidade * -1
                self.contaCaminho = 0
    # tornar monstro invisivel apos embate com flecha
    def matar(self):
        self.visivel = False

# definir tesouro
class tesouroClass(object):
    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.hitbox = (self.x + 10, self.y + 10, 20, 20)
        self.visivel = True
    #desenhar tesouro
    def desenha(self,winSize):
        if self.visivel:
            winSize.blit(items[0], (self.x, self.y))
#definir saida
class saidaClass(object):
    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.hitbox = (self.x + 17, self.y + 14, 40, 40)

    # desenhar saida
    def desenha(self,winSize):
        winSize.blit(items[1], (self.x, self.y))
        #pygame.draw.rect(winSize, (255, 0, 0), self.hitbox, 2)

#definir poco
class pocoClass(object):
    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.hitbox = (self.x + 17, self.y + 14, 20, 20)

    # desenhar poco
    def desenha(self,winSize):
        winSize.blit(items[2], (self.x, self.y))

#desenhar janela de  jogo com todos os elementos
def desenhaJanela():
    winSize.blit(background, (0, 0))
    pygame.draw.rect(winSize, (0, 0, 0), (00, 460, 500, 100))
    text1 = font.render('obtem o ouro e foge!', 1, (255, 255, 255))
    winSize.blit(text1, (10, 470))
    text = font.render('flechas: ' + str(armas), 1, (255,255,255))
    winSize.blit(text, (380, 10))
    #chamada dos elementos na janela
    poco.desenha(winSize)
    poco1.desenha(winSize)
    poco2.desenha(winSize)
    poco3.desenha(winSize)
    inimigo.desenha(winSize)
    inimigo2.desenha(winSize)
    inimigo3.desenha(winSize)
    inimigo4.desenha(winSize)
    ouro.desenha(winSize)
    saida.desenha(winSize)
    personagem.desenha(winSize)
    for flecha in flechas:
        flecha.desenha(winSize)

    pygame.display.update()


#  definicao de variaveis, chamada de classes e listas para o loop
font = pygame.font.SysFont('arial', 20, True)
personagem = jogador(20, 410, 64, 64)
inimigo = monstro(10, 210, 64, 64, 450)
inimigo2 = monstro(0, 310, 64, 64, 250)
inimigo3 = monstro(140, 410, 64, 64, 450)
inimigo4 = monstro(50, 110, 64, 64, 150)
ouro = tesouroClass(360, 360, 64, 64)
saida = saidaClass(40, 0, 100, 100)
poco = pocoClass(230, 230, 80, 80)
poco1 = pocoClass(110, 110, 80, 80)
poco2 = pocoClass(380, 380, 80, 80)
poco3 = pocoClass(330, 330, 80, 80)
atrasoDisparo = 0
flechas = []
run = True

# iniciar loop do jogo
while run:
    clock.tick(27)
    # colisao com monstro
    if inimigo.visivel == True:
        if personagem.hitbox[1] < inimigo.hitbox[1] + inimigo.hitbox[3] and personagem.hitbox[1] + personagem.hitbox[3] > inimigo.hitbox[1]:
            if personagem.hitbox[0] + personagem.hitbox[2] > inimigo.hitbox[0] and personagem.hitbox[0] < inimigo.hitbox[1] + inimigo.hitbox[2]:
                personagem.atinge()

    if inimigo2.visivel == True:
        if personagem.hitbox[1] < inimigo2.hitbox[1] + inimigo2.hitbox[3] and personagem.hitbox[1] + personagem.hitbox[3] > inimigo2.hitbox[1]:
            if personagem.hitbox[0] + personagem.hitbox[2] > inimigo2.hitbox[0] and personagem.hitbox[0] < inimigo2.hitbox[1] + inimigo2.hitbox[2]:
                personagem.atinge()

    if inimigo3.visivel == True:
        if personagem.hitbox[1] < inimigo3.hitbox[1] + inimigo3.hitbox[3] and personagem.hitbox[1] + personagem.hitbox[3] > inimigo3.hitbox[1]:
            if personagem.hitbox[0] + personagem.hitbox[2] > inimigo3.hitbox[0] and personagem.hitbox[0] < inimigo3.hitbox[1] + inimigo3.hitbox[2]:
                personagem.atinge()

    if inimigo4.visivel == True:
        if personagem.hitbox[1] < inimigo4.hitbox[1] + inimigo4.hitbox[3] and personagem.hitbox[1] + personagem.hitbox[3] > inimigo4.hitbox[1]:
            if personagem.hitbox[0] + personagem.hitbox[2] > inimigo4.hitbox[0] and personagem.hitbox[0] < inimigo4.hitbox[1] + inimigo4.hitbox[2]:
                personagem.atinge()
    # apanhar ouro
    if ouro.visivel == True:
        if personagem.hitbox[1] < ouro.hitbox[1] + ouro.hitbox[3] and personagem.hitbox[1] + personagem.hitbox[3] > ouro.hitbox[1]:
            if personagem.hitbox[0] + personagem.hitbox[2] > ouro.hitbox[0] and personagem.hitbox[0] < ouro.hitbox[1] + ouro.hitbox[2]:
                ouro.visivel = False
                pygame.draw.rect(winSize, (0, 0, 0), (00, 460, 500, 100))
                text = font.render('* ouro obtido!  volta à saída!', 1, (255, 255, 255))
                winSize.blit(text, (10, 465))
                pygame.display.update()
                i = 0
                while i < 100:
                    pygame.time.delay(10)
                    i += 1
                    for event in pygame.event.get():
                        if event.type == pygame.QUIT:
                            i = 301
                            pygame.quit()
                tesouro = 1
    # chegar a saida
    if personagem.hitbox[1] < saida.hitbox[1] + saida.hitbox[3] and personagem.hitbox[1] + personagem.hitbox[3] > saida.hitbox[1]:
        if personagem.hitbox[0] + personagem.hitbox[2] > saida.hitbox[0] and personagem.hitbox[0] < saida.hitbox[1] +  saida.hitbox[2]:
            if tesouro == 0:
                pygame.draw.rect(winSize, (0, 0, 0), (00, 460, 500, 100))
                text = font.render('* apanha o tesouro primeiro!', 1, (255, 255, 255))
                winSize.blit(text, (10, 465))
                pygame.display.update()
                i = 0
                while i < 100:
                    pygame.time.delay(3)
                    i += 1
                    for event in pygame.event.get():
                        if event.type == pygame.QUIT:
                            i = 301
                            pygame.quit()
            else:
                pygame.draw.rect(winSize, (0, 0, 0), (00, 460, 500, 100))
                text = font.render('* parabens! conseguiste escapar.', 1, (255, 255, 255))
                winSize.blit(text, (10, 465))
                pygame.display.update()
                i = 0
                while i < 6:
                    pygame.time.delay(5)
                    i += 1
                    for event in pygame.event.get():
                        i = 2
                        time.sleep(3)
                        run = False
    # cair no poco
    if personagem.hitbox[1] < poco.hitbox[1] + poco.hitbox[3] and personagem.hitbox[1] + personagem.hitbox[3] > poco.hitbox[1]:
        if personagem.hitbox[0] + personagem.hitbox[2] > poco.hitbox[0] and personagem.hitbox[0] < poco.hitbox[1] +  poco.hitbox[2]:
            personagem.atinge()
    if personagem.hitbox[1] < poco1.hitbox[1] + poco.hitbox[3] and personagem.hitbox[1] + personagem.hitbox[3] > poco1.hitbox[1]:
        if personagem.hitbox[0] + personagem.hitbox[2] > poco1.hitbox[0] and personagem.hitbox[0] < poco1.hitbox[1] +  poco1.hitbox[2]:
            personagem.atinge()
    if personagem.hitbox[1] < poco2.hitbox[1] + poco.hitbox[3] and personagem.hitbox[1] + personagem.hitbox[3] > poco2.hitbox[1]:
        if personagem.hitbox[0] + personagem.hitbox[2] > poco2.hitbox[0] and personagem.hitbox[0] < poco2.hitbox[1] +  poco2.hitbox[2]:
            personagem.atinge()
    if personagem.hitbox[1] < poco3.hitbox[1] + poco3.hitbox[3] and personagem.hitbox[1] + personagem.hitbox[3] > poco3.hitbox[1]:
        if personagem.hitbox[0] + personagem.hitbox[2] > poco3.hitbox[0] and personagem.hitbox[0] < poco3.hitbox[1] +  poco3.hitbox[2]:
            personagem.atinge()


    # flechas com distancia entre elas
    if atrasoDisparo > 0:
        atrasoDisparo += 1
    if atrasoDisparo > 4:
        atrasoDisparo = 0
    # sair do jogo
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
    # lancamento ds flechas
    for flecha in flechas:
        if flecha.y - flecha.radius < inimigo.hitbox[1] + inimigo.hitbox[3] and flecha.y + flecha.radius > inimigo.hitbox[1]:
            if flecha.x + flecha.radius > inimigo.hitbox[0] and flecha.x - flecha.radius < inimigo.hitbox[1] + inimigo.hitbox[2]:
                inimigo.matar()
                flechas.pop(flechas.index(flecha))
        if flecha.y - flecha.radius < inimigo2.hitbox[1] + inimigo2.hitbox[3] and flecha.y + flecha.radius > inimigo2.hitbox[1]:
            if flecha.x + flecha.radius > inimigo2.hitbox[0] and flecha.x - flecha.radius < inimigo2.hitbox[1] + inimigo2.hitbox[2]:
                inimigo2.matar()
                flechas.pop(flechas.index(flecha))

        if flecha.y - flecha.radius < inimigo3.hitbox[1] + inimigo3.hitbox[3] and flecha.y + flecha.radius > inimigo3.hitbox[1]:
            if flecha.x + flecha.radius > inimigo3.hitbox[0] and flecha.x - flecha.radius < inimigo3.hitbox[1] + inimigo3.hitbox[2]:
                inimigo3.matar()
                flechas.pop(flechas.index(flecha))
        if flecha.y - flecha.radius < inimigo4.hitbox[1] + inimigo4.hitbox[3] and flecha.y + flecha.radius > inimigo4.hitbox[1]:
            if flecha.x + flecha.radius > inimigo4.hitbox[0] and flecha.x - flecha.radius < inimigo4.hitbox[1] + inimigo4.hitbox[2]:
                inimigo4.matar()
                flechas.pop(flechas.index(flecha))

        if flecha.x < 500 and flecha.x > 0:
            flecha.x += flecha.velocidade

        else:
            flechas.pop(flechas.index(flecha))


    # definir input do jogador
    keys = pygame.key.get_pressed()

    # jogador dispara com a tecla espaco
    if keys[pygame.K_SPACE] and atrasoDisparo == 0:
        armas -= 1
        if armas <= 0:
            armas = 0

        if personagem.left:
            apontando = -1
        else:
            apontando = 1

        if len(flechas) <= 5:
            flechas.append(projetil(round(personagem.x + personagem.width//2), round(personagem.y + personagem.height//2), 6, (0,0,0), apontando))

        atrasoDisparo = 1
    # movimento do jogador com as setas do teclado
    if keys[pygame.K_LEFT] and personagem.x > personagem.velocidade:
        personagem.x -= personagem.velocidade
        personagem.left = True
        personagem.right = False
        personagem.up = False
        personagem.down = False
        personagem.parada = False
    elif keys[pygame.K_RIGHT] and personagem.x < 500 - personagem.width - personagem.velocidade:
        personagem.x += personagem.velocidade
        personagem.left = False
        personagem.right = True
        personagem.up = False
        personagem.down = False
        personagem.parada = False
    elif keys[pygame.K_UP] and personagem.y > personagem.velocidade:
        personagem.y -= personagem.velocidade
        personagem.left = False
        personagem.right = False
        personagem.up = True
        personagem.down = False
        personagem.parada = False
    elif keys[pygame.K_DOWN] and personagem.y < 500 - personagem.height - personagem.velocidade:
        personagem.y += personagem.velocidade
        personagem.left = False
        personagem.right = False
        personagem.up = False
        personagem.down = True
        personagem.parada = False
    else:
        personagem.parada = True
        personagem.contaCaminho = 0
    desenhaJanela()

pygame.quit()